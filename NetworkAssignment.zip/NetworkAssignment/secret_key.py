# Secret shared symmetric key. Must be 32 bytes long!
secret_key1 = "12345678123456781234567812345678" 
secret_key2 = "87654321876543218765432187654321"

def get_secret_key():
    pass